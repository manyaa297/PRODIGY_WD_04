const socket = io('http://localhost:3001');

let room = "";

function joinRoom() {
  room = document.getElementById('roomInput').value;
  if (room) {
    socket.emit('join_room', room);
  }
}

function sendMessage() {
  const messageInput = document.getElementById('messageInput');
  const message = messageInput.value;
  if (message && room) {
    socket.emit('send_message', { room, message });
    displayMessage(`You: ${message}`);
    messageInput.value = '';
  }
}

socket.on('receive_message', (data) => {
  displayMessage(`Other: ${data.message}`);
});

function displayMessage(message) {
  const messagesDiv = document.getElementById('messages');
  const newMsg = document.createElement('div');
  newMsg.textContent = message;
  messagesDiv.appendChild(newMsg);
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}